﻿namespace WindowsFormsApplication1
{
    partial class MixMatchStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MixMatchStudent));
            this.newL = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.nextThumbButton = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PreviousThumbB = new System.Windows.Forms.Button();
            this.nextThumbB = new System.Windows.Forms.Button();
            this.thumb3 = new System.Windows.Forms.Panel();
            this.thumb4 = new System.Windows.Forms.Panel();
            this.thumb5 = new System.Windows.Forms.Panel();
            this.SaveD = new System.Windows.Forms.SaveFileDialog();
            this.thumb2 = new System.Windows.Forms.Panel();
            this.OpenD = new System.Windows.Forms.OpenFileDialog();
            this.thumb1 = new System.Windows.Forms.Panel();
            this.HomeB = new System.Windows.Forms.Button();
            this.SaveB = new System.Windows.Forms.Button();
            this.OpenB = new System.Windows.Forms.Button();
            this.DeleteB = new System.Windows.Forms.Button();
            this.AddB = new System.Windows.Forms.Button();
            this.currentL = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // newL
            // 
            this.newL.AutoSize = true;
            this.newL.Location = new System.Drawing.Point(337, 200);
            this.newL.Name = "newL";
            this.newL.Size = new System.Drawing.Size(58, 13);
            this.newL.TabIndex = 74;
            this.newL.Text = "New Deck";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(10, 47);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(33, 81);
            this.button1.TabIndex = 73;
            this.button1.Text = "<<";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // nextThumbButton
            // 
            this.nextThumbButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.nextThumbButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nextThumbButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.nextThumbButton.Location = new System.Drawing.Point(702, 47);
            this.nextThumbButton.Name = "nextThumbButton";
            this.nextThumbButton.Size = new System.Drawing.Size(33, 81);
            this.nextThumbButton.TabIndex = 72;
            this.nextThumbButton.Text = ">>";
            this.nextThumbButton.UseVisualStyleBackColor = false;
            // 
            // panel7
            // 
            this.panel7.AutoSize = true;
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Location = new System.Drawing.Point(312, 47);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(124, 81);
            this.panel7.TabIndex = 71;
            // 
            // panel6
            // 
            this.panel6.AutoSize = true;
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Location = new System.Drawing.Point(442, 47);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(124, 81);
            this.panel6.TabIndex = 70;
            // 
            // panel5
            // 
            this.panel5.AutoSize = true;
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Location = new System.Drawing.Point(572, 47);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(124, 81);
            this.panel5.TabIndex = 69;
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(179, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(124, 81);
            this.panel1.TabIndex = 68;
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(49, 47);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(124, 81);
            this.panel2.TabIndex = 67;
            // 
            // PreviousThumbB
            // 
            this.PreviousThumbB.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PreviousThumbB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PreviousThumbB.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.PreviousThumbB.Location = new System.Drawing.Point(10, 230);
            this.PreviousThumbB.Name = "PreviousThumbB";
            this.PreviousThumbB.Size = new System.Drawing.Size(33, 81);
            this.PreviousThumbB.TabIndex = 66;
            this.PreviousThumbB.Text = "<<";
            this.PreviousThumbB.UseVisualStyleBackColor = false;
            // 
            // nextThumbB
            // 
            this.nextThumbB.BackColor = System.Drawing.SystemColors.ControlDark;
            this.nextThumbB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nextThumbB.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.nextThumbB.Location = new System.Drawing.Point(702, 230);
            this.nextThumbB.Name = "nextThumbB";
            this.nextThumbB.Size = new System.Drawing.Size(33, 81);
            this.nextThumbB.TabIndex = 65;
            this.nextThumbB.Text = ">>";
            this.nextThumbB.UseVisualStyleBackColor = false;
            // 
            // thumb3
            // 
            this.thumb3.AutoSize = true;
            this.thumb3.BackColor = System.Drawing.Color.White;
            this.thumb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.thumb3.Location = new System.Drawing.Point(312, 230);
            this.thumb3.Name = "thumb3";
            this.thumb3.Size = new System.Drawing.Size(124, 81);
            this.thumb3.TabIndex = 64;
            // 
            // thumb4
            // 
            this.thumb4.AutoSize = true;
            this.thumb4.BackColor = System.Drawing.Color.White;
            this.thumb4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.thumb4.Location = new System.Drawing.Point(442, 230);
            this.thumb4.Name = "thumb4";
            this.thumb4.Size = new System.Drawing.Size(124, 81);
            this.thumb4.TabIndex = 63;
            // 
            // thumb5
            // 
            this.thumb5.AutoSize = true;
            this.thumb5.BackColor = System.Drawing.Color.White;
            this.thumb5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.thumb5.Location = new System.Drawing.Point(572, 230);
            this.thumb5.Name = "thumb5";
            this.thumb5.Size = new System.Drawing.Size(124, 81);
            this.thumb5.TabIndex = 62;
            // 
            // thumb2
            // 
            this.thumb2.AutoSize = true;
            this.thumb2.BackColor = System.Drawing.Color.White;
            this.thumb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.thumb2.Location = new System.Drawing.Point(179, 230);
            this.thumb2.Name = "thumb2";
            this.thumb2.Size = new System.Drawing.Size(124, 81);
            this.thumb2.TabIndex = 61;
            // 
            // OpenD
            // 
            this.OpenD.FileName = "OpenD";
            // 
            // thumb1
            // 
            this.thumb1.AutoSize = true;
            this.thumb1.BackColor = System.Drawing.Color.White;
            this.thumb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.thumb1.Location = new System.Drawing.Point(49, 230);
            this.thumb1.Name = "thumb1";
            this.thumb1.Size = new System.Drawing.Size(124, 81);
            this.thumb1.TabIndex = 60;
            // 
            // HomeB
            // 
            this.HomeB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("HomeB.BackgroundImage")));
            this.HomeB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.HomeB.Location = new System.Drawing.Point(657, 5);
            this.HomeB.Name = "HomeB";
            this.HomeB.Size = new System.Drawing.Size(36, 36);
            this.HomeB.TabIndex = 59;
            this.HomeB.UseVisualStyleBackColor = true;
            this.HomeB.Click += new System.EventHandler(this.HomeB_Click_1);
            // 
            // SaveB
            // 
            this.SaveB.Location = new System.Drawing.Point(386, 143);
            this.SaveB.Name = "SaveB";
            this.SaveB.Size = new System.Drawing.Size(144, 39);
            this.SaveB.TabIndex = 57;
            this.SaveB.Text = "Save New Deck";
            this.SaveB.UseVisualStyleBackColor = true;
            // 
            // OpenB
            // 
            this.OpenB.Location = new System.Drawing.Point(536, 143);
            this.OpenB.Name = "OpenB";
            this.OpenB.Size = new System.Drawing.Size(157, 39);
            this.OpenB.TabIndex = 58;
            this.OpenB.Text = "Open Different Deck";
            this.OpenB.UseVisualStyleBackColor = true;
            // 
            // DeleteB
            // 
            this.DeleteB.Location = new System.Drawing.Point(235, 143);
            this.DeleteB.Name = "DeleteB";
            this.DeleteB.Size = new System.Drawing.Size(145, 39);
            this.DeleteB.TabIndex = 56;
            this.DeleteB.Text = "Delete Current Card";
            this.DeleteB.UseVisualStyleBackColor = true;
            // 
            // AddB
            // 
            this.AddB.Location = new System.Drawing.Point(75, 143);
            this.AddB.Name = "AddB";
            this.AddB.Size = new System.Drawing.Size(154, 39);
            this.AddB.TabIndex = 55;
            this.AddB.Text = "Add to New Deck";
            this.AddB.UseVisualStyleBackColor = true;
            // 
            // currentL
            // 
            this.currentL.AutoSize = true;
            this.currentL.Location = new System.Drawing.Point(337, 19);
            this.currentL.Name = "currentL";
            this.currentL.Size = new System.Drawing.Size(70, 13);
            this.currentL.TabIndex = 54;
            this.currentL.Text = "Current Deck";
            // 
            // MixMatchStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 330);
            this.Controls.Add(this.newL);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.nextThumbButton);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.PreviousThumbB);
            this.Controls.Add(this.nextThumbB);
            this.Controls.Add(this.thumb3);
            this.Controls.Add(this.thumb4);
            this.Controls.Add(this.thumb5);
            this.Controls.Add(this.thumb2);
            this.Controls.Add(this.thumb1);
            this.Controls.Add(this.HomeB);
            this.Controls.Add(this.SaveB);
            this.Controls.Add(this.OpenB);
            this.Controls.Add(this.DeleteB);
            this.Controls.Add(this.AddB);
            this.Controls.Add(this.currentL);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MixMatchStudent";
            this.Text = "Mix and Match";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label newL;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button nextThumbButton;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button PreviousThumbB;
        private System.Windows.Forms.Button nextThumbB;
        private System.Windows.Forms.Panel thumb3;
        private System.Windows.Forms.Panel thumb4;
        private System.Windows.Forms.Panel thumb5;
        private System.Windows.Forms.SaveFileDialog SaveD;
        private System.Windows.Forms.Panel thumb2;
        private System.Windows.Forms.OpenFileDialog OpenD;
        private System.Windows.Forms.Panel thumb1;
        private System.Windows.Forms.Button HomeB;
        private System.Windows.Forms.Button SaveB;
        private System.Windows.Forms.Button OpenB;
        private System.Windows.Forms.Button DeleteB;
        private System.Windows.Forms.Button AddB;
        private System.Windows.Forms.Label currentL;

    }
}