using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class Score
{
    public int index;
    public int value;

    public Score()
    {
        index = 0;
        value = 0;
    }
}
